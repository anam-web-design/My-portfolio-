(function(){
  var ids = [
    'home',
    'about',
    'skills',
    'projects',
    'services',
    'contact'
  ];

  var links = document.querySelectorAll('.rail a,nav ul a');

  function mark(id){
    links.forEach(function(a){
      a.classList.toggle(
        'on',
        a.getAttribute('href') === '#' + id
      );
    });
  }

  if(!('IntersectionObserver' in window)) return;

  var io = new IntersectionObserver(
    function(es){
      es.forEach(function(e){
        if(e.isIntersecting){
          mark(e.target.id);
        }
      });
    },
    {
      rootMargin:'-40% 0px -55% 0px'
    }
  );

  ids.forEach(function(i){
    var el = document.getElementById(i);

    if(el){
      io.observe(el);
    }
  });
})();
